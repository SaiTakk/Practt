class Pract4A
{
	public Pract4A()
	{
		System.out.println("Hello");
	}
	public void finalize()
	{
		System.out.println("Destrying object.");
	}
	public static void main(String[] args)
	{
	Pract4A obj=new Pract4A();
	obj=null;
	System.gc();
	}
}