class Pract3C
{
	public static void main(String[] args)
	{
		int number[]=new int[] {1,10,7,6,5,12,13,25,31,40};
		int smallest=number[0];
		int largest=number[0];
		
		for(int i=1;i<number.length;i++)
		{
			if(number[i]>largest)
			{
				largest=number[i];
			}
			else if(number[i]<smallest)
			{
				smallest=number[i];
			}
		}
		
		System.out.println("Largest no:"+largest);
		System.out.println("Smallest no:"+smallest);
	}
}	