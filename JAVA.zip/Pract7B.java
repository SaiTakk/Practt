class Pract7B
{
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getName());
		for(int i=1;i<=5;i++)
		{
			new Thread(" "+i)
			{
				public void run()
				{
					System.out.println("Thread "+getName()+" Running");
				}
			}.start();
		}
	}
}