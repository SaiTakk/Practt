class Emp
{
	static int salary=30000;
}

class Pract5A
{
	int s=10000;
	public static void main(String[] args)
	{
		Pract5A obj=new Pract5A();
		System.out.println("Salary:"+Emp.salary);
		System.out.println(obj.s);
	}
}