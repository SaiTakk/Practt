import java.util.Scanner;

class Pract3B
{
	public void count()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		String str=sc.nextLine();
		int sum=0;
		char[] ch=str.toCharArray();
		
		for(int i=0;i<str.length();i++)
		{
			if(Character.isDigit(ch[i]))
				{
					sum+=Character.getNumericValue(ch[i]);
				}
		}
		System.out.println("Sum:"+sum);
	}
	
	public static void main(String[] args)
	{
		Pract3B obj=new Pract3B();
		obj.count();
	}
}