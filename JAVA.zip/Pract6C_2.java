import data.Pract6C_1;

	class Pract6C_2
	{
		public static void main(String[] args)
		{
			Pract6C_1 d=new Pract6C_1();
			d.display();
			d.show();
		}
	}
	