import java.util.Vector;

class Pract7A
{
	public static void main(String[] args)
	{
		Vector<String> v=new Vector<String>();
		v.add("Black");
		v.add("Blue");
		v.add("White");
		
		System.out.println("Vector Elements:"+v);
		v.add(1,"Green");
		System.out.println("Vector Elements:"+v);
		System.out.println("At index 2:"+v.get(2));
		System.out.println("First Elements:"+v.firstElement());
		System.out.println("Last Element:"+v.lastElement());
		System.out.println("Is Empty:"+v.isEmpty());
	}
}