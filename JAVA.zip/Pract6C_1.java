class Pract6C_1
{
	public void display()
	{
		System.out.println("Welcome");
	}
	
	public void show()
	{
		System.out.println("Hello");
	}
}