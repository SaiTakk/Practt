import java.util.Scanner;

class Pract6B
{
	public static void main(String[] args)
	{
		int i,j;
		int mat1[][]=new int[2][2];
		int mat2[][]=new int[2][2];
		int mat3[][]=new int[2][2];
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter elements of first matrix:");
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				mat1[i][j]=sc.nextInt();
			}
		}
		
		System.out.println("Enter elements of second matrix:");
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				mat2[i][j]=sc.nextInt();
			}
		}
		
		System.out.println("Multiplication of two matrices:");
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				mat3[i][j]=mat1[i][j]*mat2[i][j];
				System.out.print(mat3[i][j]+" ");
			}
		}
	}
}