import java.io.*;

class A extends Thread
{
	public void run()
	{
		System.out.println("Thread A started");
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread A "+i);
		}
	}
}

class B extends Thread
{
	public void run()
	{
		System.out.println("Thread B started");
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread B "+i);
		}
	}
}

class C extends Thread
{
	public void run()
	{
		System.out.println("Thread C started");
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread C "+i);
		}
	}
}

class Pract7C
{
	public static void main(String[] args)
	{
		new A().start();
		new B().start();
		new C().start();
	}
}