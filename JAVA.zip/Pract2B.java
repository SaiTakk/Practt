import java.util.Scanner;

class Pract2B
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String reverse=" ",Original;
		System.out.println("Enter string Value:");
		Original=sc.nextLine();
		int len=Original.length();
		for(int i=len-1;i>=0;i--)
		{
			
			reverse=reverse + Original.charAt(i);
		}
		System.out.println("Reverse of string:"+reverse);
	}
}