import java.util.Scanner;

class Pract1B
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of radius:");
		int r=sc.nextInt();
		double area=Math.PI*r*r;
		double perimeter=2*Math.PI*r;
		System.out.println("Area of circe:"+area);
		System.out.println("Perimeter of circle:"+perimeter);
	}
}