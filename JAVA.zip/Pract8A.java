import java.awt.*;							//more info:https://www.javatpoint.com/java-awt
import java.awt.event.*;					//more info ^^^link above^^^

class Pract8A extends Frame implements ActionListener  	//Create Class
{
	TextField tf;							//Define Stuff
	Button b;
	Label n,l,r;
	
	Pract8A()								//class Constructor
	{
		l=new Label("Enter number:");		//initiate stuff more info:https://www.javatpoint.com/java-awt
		r=new Label();
		tf=new TextField();
		b=new Button("Factorial");				
		l.setBounds(30,40,200,20);			//set position
		r.setBounds(30,170,200,20);
		tf.setBounds(30,90,190,30);
		b.setBounds(30,130,190,30);
		add(l);								//add stuff
		add(r);
		add(tf);
		add(b);
		setSize(250,210);					//set size
		setLayout(null);
		setVisible(true);
		
		b.addActionListener(this);						//Action listener (this)=current object=b=Button (line 15) more info:https://www.w3schools.com/java/ref_keyword_this.asp
		addWindowListener(new WindowAdapter()			//add WindowListener override with Window adaptor more info:https://www.javatpoint.com/java-actionlistener
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();								//more info:https://chortle.ccsu.edu/java5/notes/chap64/ch64_10.html
			}
		});
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b)
		{
			int num=Integer.parseInt(tf.getText());
			r.setText("Factorial of "+num+" is "+getFactorial(num));
		}
	}	
	
	public int getFactorial(int x)			//method
	{
		int rsl=1;
		for(int i=x;i>0;i--)
		{
			rsl*=i;
		}
		return(rsl);
	}
	
	public static void main(String[] agrs)	//main function
	{
		Pract8A factorial=new Pract8A();
	}
}