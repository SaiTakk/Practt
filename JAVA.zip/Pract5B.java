class College
{
	public void move()
	{
		System.out.println("College is open.");
	}
}

class Building_1
{
	public void move()
	{
		System.out.println("Building 1 is open.");
	}
}

class Pract5B
{
	public static void main(String[] args)
	{
		College c=new College();
		Building_1 b=new Building_1();
		c.move();
		b.move();
	}
}