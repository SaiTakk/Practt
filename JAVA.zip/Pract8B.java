import java.awt.*;
import java.awt.event.*;

class Pract8B extends Frame implements ActionListener
{
	Label l;
	TextField tf;
	Button b;
	TextArea ta;
	
	Pract8B()
	{
		l=new Label("String 1(l)");
		tf=new TextField();
		b=new Button("Operations");
		ta=new TextArea(" aaaa",2,100,TextArea.SCROLLBARS_NONE);
		
		l.setBounds(10,40,100,0);
		tf.setBounds(10,65,100,20);
		b.setBounds(10,90,210,30);
		ta.setBounds(10,150,270,30);
		ta.setEditable(false);
		
		add(l);
		add(tf);
		add(b);
		add(ta);
		b.addActionListener(this);
		setTitle("String Operations");
		setSize(230,240);
		setLayout(null);
		setVisible(true);
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b)
		{
			String str=tf.getText();
			StringBuilder sb=new StringBuilder(str);
			String opr=sb.reverse().toString();			//String Buider more info :https://www.geeksforgeeks.org/stringbuilder-class-in-java-with-examples/
			ta.setText(opr);
		}
	}
	
	public static void main(String[] args)
	{
		Pract8B StringFunc=new Pract8B();
	}
}