abstract class calc
{
	public abstract int sqr(int n1);
	public abstract int cube(int n2);
	public void show()
	{
		System.out.println("Hello");
	}
}

public class Pract4B extends calc
{
	public int sqr(int n1)
	{
		return n1*n1;
	}
	
	public int cube(int n2)
	{
		return n2*n2*n2;
	}
	
	public static void main(String[] args)
	{
		Pract4B obj=new Pract4B();
		System.out.println("Square of 4:"+obj.sqr(4));
		System.out.println("Cube of 3:"+obj.cube(3));
	}
}