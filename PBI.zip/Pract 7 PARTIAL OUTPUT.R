data ("iris")
summary(iris)
head(iris)
#ONE TIME USE install.packages("ClusterR")
#ONE TIME USE install.packages("cluster")
library(ClusterR)
library(cluster)
iris_1<-iris[,-5]
set.seed(240)
kmeans.re<-kmeans(iris_1,center=3,nstart=20)
kmeans.re$cluster
head(kmeans.re$cluster,3)
kmeans.re$size
kmeans.re$centers
plot(iris_1[c("Sepal.Length","Sepal.Width")],)
