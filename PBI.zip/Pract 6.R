#ONE TIME ONLY install.packages("party")
library("party")
print(head(readingSkills))
input.data <- readingSkills[c(1:105),]
output.tree <-ctree(nativeSpeaker ~ age + shoeSize + score,data = input.data)
plot(output.tree)