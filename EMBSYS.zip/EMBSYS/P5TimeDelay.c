/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 3/20/2024
Author  : 
Company : 
Comments: 


Chip type               : AT90S8535
AVR Core Clock frequency: 1.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 128
*******************************************************/

#include <90s8535.h>

// Declare your global variables here

unsigned int timecount=0;
unsigned int led_status=0x00;
interrupt [TIM0_OVF]void timer0_ofv_isr(void)
{
	TCNT0=6;
	if(++timecount ==500)
	{
		timecount=0;
		if(led_status==0x00)
			led_status=0x01;
		else
			led_status=0x00;
		PORTA=led_status;
	}
}

void main(void)
{
	DDRA=0x80;
	PORTA=led_status;
	TCCR0=0x02;
	TCNT0=0x00;
	TIMSK=0x01;
	#asm("sei");
	while(1);
}

