#include<reg51.h>
#include<intrins.h>

void main()
{
	P1=0x00;
	while(1)   //While (1) is infite loop more info:https://www.geeksforgeeks.org/difference-while1-while0-c-language/
	{
		do
		{
			P1+=0x05;
		}
		while(P1<0xFF);
		do
		{
			P1-=0x05;
		}
		while(P1>0x00);
	}
}