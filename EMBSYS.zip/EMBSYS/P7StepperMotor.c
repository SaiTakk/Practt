/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 3/21/2024
Author  : 
Company : 
Comments: 


Chip type               : AT90S8535
AVR Core Clock frequency: 1.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 128
*******************************************************/

#include <90s8535.h>
#include <delay.h>

unsigned int motor_statusA=0x00;
unsigned int motor_statusB=0x00;
void main (void)
{
	DDRA=0xff;
	DDRB=0xff;
	#asm("sei");
	while(1)
	{
		if(motor_statusA==0x00)
		{
			motor_statusA=0x01;
			motor_statusB=0x08;
		}
		PORTA=motor_statusA;
		PORTB=motor_statusB;
		motor_statusA<<=1;
		motor_statusB>>=1;
		delay_ms(500);
		
		if(motor_statusA==0x10)
		{
			motor_statusA=0x01;
			motor_statusB=0x08;
			PORTA=motor_statusA;
			PORTB=motor_statusB;
			delay_ms(500);
			motor_statusB=0x08;
		}
	}
}

			
