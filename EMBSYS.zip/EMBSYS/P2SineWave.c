#include<reg51.h>
#include<intrins.h>

void main()
{
	unsigned i;
	unsigned int waveValue[39]={127,146,198,213,226,236,245,254,252,247,239,229,217,203,187,170,152,133,115,96,78,61,46,33,21,12,5,1,0,1,5,12,21,33,46,78,96,115};
		
	while(1)
	{
		for(i=0;i<39;i++)
		{
			P1=waveValue[i];
			_nop_();
			_nop_();
			_nop_();
			_nop_();
			_nop_();
			_nop_();
		}
	}
}
			