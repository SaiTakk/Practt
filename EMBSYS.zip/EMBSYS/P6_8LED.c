/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 3/21/2024
Author  : 
Company : 
Comments: 


Chip type               : AT90S8535
AVR Core Clock frequency: 1.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 128
*******************************************************/

#include <90s8535.h>
#include <delay.h>

void main(void)
{
	PORTA=0x00;
	DDRB=0xff;
	while(1)
	{
		PORTA=0x01;
		delay_ms(500);
		PORTA=0x02;
		delay_ms(500);
		PORTA=0x04;
		delay_ms(500);
		PORTA=0x08;
		delay_ms(500);
		PORTA=0x10;
		delay_ms(500);
		PORTA=0x20;
		delay_ms(500);
		PORTA=0x40;
		delay_ms(500);
		PORTA=0x80;
		delay_ms(500);
	}
}
