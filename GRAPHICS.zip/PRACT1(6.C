#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode,errorcode;
int maxx,maxy;
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
errorcode=graphresult();
if(errorcode!=grOk)
{
printf("Graphics Error:%d\n",grapherrormsg(errorcode));
printf("Press any key to halt");
getch();
exit(1);
}
maxx=getmaxx();
maxy=getmaxy();
setcolor(getmaxcolor());
setfillstyle(SOLID_FILL,getmaxcolor());
rectangle(0,0,maxx,maxy);
circle(maxx/3,maxy/2,50);
circle(maxx/2,20,100);
circle(maxx-20,maxy-50,75);
circle(20,maxy-20,25);
getch();
floodfill(2,2,getmaxcolor());
getch();
closegraph();
return 0;
}