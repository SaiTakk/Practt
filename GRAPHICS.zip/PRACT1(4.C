#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode,errorcode;
int midx,midy,radius=100;
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
errorcode=graphresult();
if(errorcode!=grOk)
{
printf("Graphics Error:%d\n",grapherrormsg(errorcode));
printf("Press any key to halt");
getch();
exit(1);
}
midx=getmaxx()/2;
midy=getmaxy()/2;
setcolor(getmaxcolor());
circle(midx,midy,radius);
getch();
closegraph();
return 0;
}
