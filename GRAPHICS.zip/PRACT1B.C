#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode,errorcode;
int maxx,maxy;
int midx,midy;
int poly[10];
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
errorcode=graphresult();
clrscr();
if(errorcode!=grOk)
{
printf("Graphics Error:%d\m",grapherrormsg(errorcode));
printf("Press any key to halt");
getch();
exit(1);
}
maxx=getmaxx();
maxy=getmaxy();
poly[0]=20;
poly[1]=maxy/2;
poly[2]=maxx-20;
poly[3]=20;
poly[4]=maxx-50;
poly[5]=maxy-20;
poly[6]=maxx/2;
poly[7]=maxy/2;
poly[8]=poly[0];
poly[9]=poly[1];
drawpoly(5,poly);
getch();
closegraph();
return 0;
}