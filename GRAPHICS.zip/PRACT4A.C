#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
float x,y,x1,y1,x2,y2,dy,dx,step;
int i, gd=DETECT,gm;
clrscr();
printf("Enter value of x1:");
scanf("%f",&x1);
printf("Enter value of y1:");
scanf("%f",&y1);
printf("Enter value of x2:");
scanf("%f",&x2);
printf("Enter value of y2:");
scanf("%f",&y2);
//To check values are stored correctly
//printf("%f\n%f\n%f\n%f\n",x1,y1,x2,y2);
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
dx=(x2-x1);
dy=(y2-y1);
if(dx>=dy)
{
step=dx;
}
else
{
step=dy;
}
dx=dx/step;
dy=dy/step;
x=x1;
y=y1;
i=1;
while(i<=step)
{
putpixel(x,y,WHITE);
x=x+dx;
y=y+dy;
i=i+1;
delay(10);
}
getch();
closegraph();
return 0;
}