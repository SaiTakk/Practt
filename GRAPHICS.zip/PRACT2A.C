#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gd=DETECT,gm;
int poly[12]={350,450,350,360,430,350,350,350,250,430,350,450};
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
circle(100,100,50);
outtextxy(75,170,"Circle");
rectangle(200,100,400,150);
outtextxy(300,170,"Rectangle");
ellipse(500,100,0,360,70,50);
outtextxy(480,170,"Ellipse");
line(100,250,500,250);
outtextxy(300,300,"Line");
sector(100,350,0,270,70,70);
outtextxy(100,425,"Sector");
drawpoly(6,poly);
outtextxy(400,425,"<-Poly");
getch();
closegraph();
return 0;
}