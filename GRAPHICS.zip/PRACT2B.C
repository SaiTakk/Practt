#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gd=DETECT,gm;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
setcolor(WHITE);
rectangle(150,150,250,300);
rectangle(250,150,450,300);
rectangle(180,250,220,300);
line(150,150,200,80);
line(200,80,400,80);
line(400,80,450,150);
line(200,80,250,150);
setfillstyle(SOLID_FILL,BROWN);
floodfill(152,182,WHITE);
floodfill(252,182,WHITE);
setfillstyle(SLASH_FILL,BLUE);
floodfill(182,252,WHITE);
setfillstyle(HATCH_FILL,GREEN);
floodfill(202,102,WHITE);
floodfill(302,102,WHITE);
getch();
closegraph();
return 0;
}