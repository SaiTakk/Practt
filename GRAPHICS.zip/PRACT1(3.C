#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode,errorcode;
int x,y;
clrscr();
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
errorcode=graphresult();
if(errorcode!=grOk)
{
printf("Graphics Error:%s\n",grapherrormsg(errorcode));
printf("Press any key to halt");
getch();
exit(1);
}
x=getmaxx()/2;
y=getmaxy()/2;
settextjustify(CENTER_TEXT,CENTER_TEXT);
outtextxy(x,y,"Press a key to close the graphics system");
getch();
closegraph();
printf("You're back to text mode");
printf("press any key to halt");
getch();
return 1;
}
