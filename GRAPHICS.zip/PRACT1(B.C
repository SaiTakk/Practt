#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode;
int midx,midy;
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
cleardevice();
midx=getmaxx()/2;
midy=getmaxy()/2;
line(1,midy,640,midy);
line(midx,1,midx,480);
getch();
closegraph();
return 0;
}