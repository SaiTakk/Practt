#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

void boundryFill(int,int,int,int);
int midx=319,midy=239;

int main()
{
int gd=DETECT,gm,x,y,r;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
printf("\nEnter the center of the circle(x.y):");
scanf("%d%d",&x,&y);
printf("\tEnter the radius of the circle:");
scanf("%d",&r);
circle(midx+x,midy-y,r);
getch();
boundryFill(midx+x,midy-y,13,15);
closegraph();
return 0;
}

void boundryFill(int x,int y,int fill,int boundry)
{
if((getpixel(x,y)!=fill)&&(getpixel(x,y)!=boundry))
{
putpixel(x,y,fill);
delay(5);
boundryFill(x+1,y,fill,boundry);
boundryFill(x-1,y,fill,boundry);
boundryFill(x,y+1,fill,boundry);
boundryFill(x,y-1,fill,boundry);
}
}
