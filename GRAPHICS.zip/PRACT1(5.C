#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gdrive=DETECT,gmode,errorcode;
int midx,midy;
initgraph(&gdrive,&gmode,"C:\\TURBOC3\\BGI");
errorcode=graphresult();
if(errorcode!=grOk)
{
printf("Graphics Error:%d\n",grapherrormsg(errorcode));
printf("Press any key to Halt");
getch();
exit(1);
}
midx=getmaxx()/2;
midy=getmaxy()/2;
setcolor(getmaxcolor());
settextjustify(CENTER_TEXT,CENTER_TEXT);
outtextxy(midx,midy,"Press any key to clear screen");
getch();
cleardevice();
outtextxy(midx,midy,"Press any key to exit");
getch();
closegraph();
return 0;
}