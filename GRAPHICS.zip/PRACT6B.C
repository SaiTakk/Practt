#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

int main()
{
int gd=DETECT,gm;
int i,x1,y1,x2,y2,x,y;
printf("Enter the 2 line end points");
printf("\nX1,Y1,X2,Y2:");
scanf("%d%d%d%d",&x1,&y1,&x2,&y2);

initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
line(x1,y1,x2,y2);
printf("Enter translation co-ordinates:");
printf("X,Y:");
scanf("%d%d",&x,&y);
x1=(x1+x);
y1=(y1+y);
x2=(x2+x);
y2=(y2+y);

printf("Line after Translation:");
line(x1,y1,x2,y2);
getch();
closegraph();
return 0;
}