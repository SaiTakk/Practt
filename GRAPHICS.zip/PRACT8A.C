#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
int gd=DETECT,gm,x=600,i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
for(x=0;x<=250;x++)
{
x%=250;
cleardevice();
setcolor(RED);
outtextxy(50,415-2*x,"*Welcome*");
setcolor(GREEN);
outtextxy(200,415-2*x,"*to*");
setcolor(YELLOW);
settextstyle(3,0,2);
outtextxy(350,415-2*x,"*Computer Grapics*");
}
getch();
closegraph();
}
