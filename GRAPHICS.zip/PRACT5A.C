#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

void pixel(int xc,int yc,int x,int y);

int main()
{
int gd=DETECT,gm;
int r,xc,yc,x,y,m,i;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
printf("Midpoint subdivision algorithm in circle\n");
printf("Enter the value of xc:\t");
scanf("%d",&xc);
printf("Enter the value of yc:\t");
scanf("%d",&yc);
printf("Enter the radius of the circle:\t");
scanf("%d",&r);
x=0;
y=r;
m=1-r;
pixel(xc,yc,x,y);
while(x<y)
{
if(m<0)
{
x=x+1;
m=m+(2*x)+1;
}
else
{
x=x+1;
y=y-1;
m=m+(2*x)-(2*y)+1;
}
pixel(xc,yc,x,y);
}
getch();
closegraph();
return 0;
}

void pixel(int xc,int yc, int x, int y)
{
putpixel(xc+x,yc+y,1);
putpixel(xc+y,yc+x,2);
putpixel(xc-y,yc+x,3);
putpixel(xc-x,yc+y,4);
putpixel(xc-x,yc-y,5);
putpixel(xc-y,yc-x,6);
putpixel(xc+y,yc-x,7);
putpixel(xc+x,yc-y,8);
}