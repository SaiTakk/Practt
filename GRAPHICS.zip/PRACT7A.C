#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

void floodFill(int,int,int,int);
int midx=319,midy=239;

int main()
{
int gd=DETECT,gm,x,y,r;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
cleardevice();
printf("\n\tEnter the center of the circle(x,y):");
scanf("%d%d",&x,&y);
printf("\tEnter the radius of the circle:");
scanf("%d",&r);
circle(midx+x,midy-y,r);
getch();
floodFill(midx+x,midy-y,15,0);
getch();
closegraph();
return 0;
}

void floodFill(int x,int y, int fill,int old)
{
if(getpixel(x,y)==old)
{
putpixel(x,y,fill);
delay(5);
floodFill(x+1,y,fill,old);
floodFill(x-1,y,fill,old);
floodFill(x,y+1,fill,old);
floodFill(x,y-1,fill,old);
}
}