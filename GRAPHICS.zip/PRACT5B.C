#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>

void disp();
int xc,yc;
float x,y;

int main()
{
int gd=DETECT,gm,a,b;
float p1,p2;
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
printf("Ellipse generating algorithm:\n");
printf("Enter the value of xc:\t");
scanf("%d",&xc);
printf("Enter the value of yc:\t");
scanf("%d",&yc);
printf("Enter x-axis length:\t");
scanf("%d",&a);
printf("Enter y-axis length:\t");
scanf("%d",&b);
x=0;
y=b;
disp();
p1=(b*b)-(a*a*b)+(a*a)/4;
while((2.0*b*b*x)<=(2.0*a*a*y))
{
x++;
if(p1<=0)
{
p1=p1+(2.0*b*b*x)+(b*b);
}
else
{
y--;
p1=p1+(2.0*b*b*x)+(b*b)-(2.0*a*a*y);
}
disp();
x=x;
disp();
x=-x;
delay(10);
}
x=a;
y=0;
disp();
p2=(a*a)+2.0*(b*b*a)+(b*b)/4;
while((2.0*b*b*x)>(2.0*a*a*y))
{
y++;
if(p2>0)
{
p2=p2+(a*a)-(2.0*a*a*y);
}
else
{
x--;
p2=p2+(2.0*b*b*x)-(2.0*a*a*y)+(a*a);
}
disp();
y=-y;
disp();
y=-y;
delay(10);
}
getch();
closegraph();
return 0;
}

void disp()
{
putpixel(xc+x,yc+y,1);
putpixel(xc-x,yc+y,2);
putpixel(xc+x,yc-y,3);
putpixel(xc-x,yc-y,4);
}
