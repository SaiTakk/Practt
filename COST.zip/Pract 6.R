Data=read.csv(file.choose(),header=T)
Data
attach(Data)
attach(Data)
chisq.test(Frequency)			#perform Chi-Square Test on Frequency col
