#ALL THE CODE SHOULD NOT BE EXECUTED AT ONCE ONE SECTION AT A TIME
#SECTIONS ARE THE COMMENTS STARTING WITH ...

#...Basic Commands...
text<-"Good Morning"			#Store string in variable text
text						#print Text
print(text)					#print Text

#...variable Assignment...
var_1 <-c(1,2,3,4,5)			#Create a vector by using c(...)
var_1						#Print var_1

var_2=c("hmmmm")				#Create vector using = instead of <-
var_2

c("Hmmmm","interesting")->var_3	#Create vector other way around
var_3

#...Remove Variable...
rm(var_3)					#remove vatiable
var_3						#should give "Error: object 'var_3' not found"

#...Arithematic Operators...
p<-c(1,2,3,4,5)				#Vector p
q<-c(2,3,4,5,6)				#Vector q
p+q						
p-q
p*q
p/q

#...if p and q are not same length it'll loop around... 
p<-c(1,2,3,4,5)				#Vector p
q<-c(2,3,4,5)				#Vector q
#output will loop back and take first element 2 in this case for use with 5
p+q 						
p-q
p*q
p/q

#...Relational Operators...
p<-c(3,2.2,6)				#Vector p
q<-c(8,3,4)					#Vector q
p>q
p<q
p==q
p!=q
p<=q
p>=q
#if p and q are not same length the shorter one will always win

#...Misc Stuff...
v<-1:10					#Creating a sequence form 1 to 10
v

v=(seq(2,4, by=0.2))			#Creating a vector with elements from 2 to 4 by difference of 0.2
v
#or directly use below for same output 
seq(2,4,by=0.2)

#...Vectors...
colors<-c("Red","Green","Yellow")	#Vector with Strings as elements insted of numbers
colors

#Below will work too
colors=c("Red","Green","Yellow")
colors

numb=c(1,2,3)
numb

comp=c(2+3i)
comp

integ=c(23L)
integ

Bool=c(TRUE)
Bool

#class prints the types of the vector Character, Numeric, Complex, Integer or Logical 
class(colors)				#Character type				
class(numb)					#Numeric type
class(comp)					#Complex number type
class(integ)				#Integer type
class(Bool)					#Boolean type

#...List...

#Creating a List which had number, vector string and boolean at once
list_1<-list("Hmmmm","Intersting","Vector",c(1,2,3),TRUE,11.05,12)
list_1

#naming list elements from above list
names(list_1)<-c("Ele1","Ele2","Ele3","Ele4","Ele5","Ele6","Ele7")
list_1


list_2<-list(c("April","May","June"),matrix(c(1,2,3,4,5,6),nrow=2))
list_2
names(list_2)<-c("2nd Quarter","A Matrix")
list_2

#mergin lists
l1=c(1,2,3)
l2=c("Red","Green","Blue")
l3=c(l1,l2)
l3

#...Matrix...

#Creating a matrix
m=matrix(c(1,2,3,4,5,6,7,8,9),nrow=3,ncol=3,byrow=TRUE)
m

#...Arrays...
p<-c(1,2,3)
q<-c(10,11,12,13,15,16)
#Creating an Array
r<-array(c(p,q),dim=c(3,3,3))		#dimensions= first two 3 are rows and col, Second 3 is no of outputs 
r
#Another example to understand third 3 in dim
r<-array(c(p,q),dim=c(2,2,3))
r

#Naming cols ,row and matrix
p<-c(1,2,3)
q<-c(10,11,12,13,15,16)
col.names=c("Col1","Col2","Col3")
row.names=c("Row1","Row2","Row3")
mat.names=c("Matrix1","Matrix2")
r=array(c(p,q),dim=c(3,3,2),dimnames=list(row.names,col.names,mat.names))	#dimnames should be rows,cols and matrix in order
r

#Accessing array element
r[3,1,2]					#[1,2,3] 1 is the row, 2 is the column, 3 is the result


#...Data Frames...
college=data.frame(Name=c("Ash","Bsh","Csh","Dsh"),Age=c(22,23,24,25),Location=c("Pune","Mumbai","Thane","Bandra"))
college

#...Build in Function...
seq(11,20)					#Seqence from 11 to 20
mean(11:20)					#Mean from 11 to 20
sum(11:20)					#Sum from 11 to 20
max(11:20)					#Max from 11 to 20
min(11:20)					#Min from 11 to 20

#...User Defined Function...
#Function with arguement
new_function_1<-function(a)
{
for(i in 1:a)
{
b<-i^2
print(b)					#Use of print is REQUIRED
}
}
new_function_1(7)

#Function without Arguement
new_function_2<-function()
{
for(i in 1:4)
{
b<-i^2
print(b)
}
}
new_function_2()

#Function with Default arguement values
new_function_3<-function(a=5,b=10)
{
c<-a+b
print(c)
}
new_function_3()				#Function will use Default values(a=5,b=10)
new_function_3(3,5)			#Function will use provided values(a=3,b=5)

#...If statement...
x<-"Hello"
if(is.character(x))
{
print("x is character")
}

#...else if...
x<-c("Yes","is","No")
if("Yes" %in% x)
{
print("Yes found first time")
}else if("Yes"%in% x)
{
print("Yes found second time")
}else
{
print("Yes not found")
}

#...else if...
x<-c("Yes","is","No")
if("Yes" %in% x)
{
print("Yes found first time")
}else
{
print("Yes not found")
}

#...Switch statement...
x=switch(2,"First","Second","Third","Fouth")
x



