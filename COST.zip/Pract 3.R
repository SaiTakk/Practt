#...Mean and Median...
#EXAMPLE 1
a=c(10,20,30,50,60,70,80)
mean(a)
median(a)

#EXAMPLE 2
x=c(2,3,4,5,6,7,8,9,10,11,12,13)
y=c(3,8,10,12,16,14,10,8,17,5,3,1)
table=data.frame(x,y)
names(table)=c("X","Frequency")
table
z=rep(x,y)					#Represent table so 2 with 3 freq is (2,2,2...
z
mean(z)
median(z)

#EXAMPLE 3
LowerLimit=seq(from=15,to=50,by=5)
UpperLimit=seq(from=20,to=55,by=5)
Freq=c(9,12,16,26,14,12,6,5)
ClassMark=(LowerLimit + UpperLimit)/2
table=data.frame(LowerLimit,UpperLimit,ClassMark,Freq)
names(t)=c("Lower Limit","Upper Limit","Class Mark","Frequency")
table
y=rep(ClassMark,Freq)
y
me(y)
median(y)

#...Mode...
x=c(40,67,75,48,44,53,56,43,66,57,65,52,83,83,80,76,85,88,89,87)
mode<-function(y)
{
tab<-table(y)
ind<-tab[tab==max(tab)]			#Number with highest freq which is 83 in this case
mo<-as.numeric(names(ind))		#remove freq from ind result
return(mo)
}
z=mode(x)
z

#...Quantile, Percentile,Quartile,Interquartile and Range...
y=c(40,67,75,48,44,53,56,43,66,57,65,52,83,83,80,76,85,88,89,87)
dg=quantile(y,0.9)
dg
pg=quantile(y,0.78)
pg
quantile(0.25,0.50,0.75,y)
IQR(y)
range=(max(y)-min(y))
range

#...Mean and Median with NA...
x=c(20,40,50,15,18,20,NA,30)
mean(x)					#output will be NA
median(x)					#output will be NA
mean(x,na=TRUE)				#Proper Output
median(x,na=TRUE)				#Proper Output

#...Histogram...
x=c(1,2,2,2,2,5,7)
hist(x)					#Graph output


