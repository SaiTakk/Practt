#TEST OF SIGNIFICANCE FOR SINGLE MEAN
#Q1 	Test the hypothesis H0:u=10 against H1:u=/=10 random sample of the size 
#	400 is drawn given mean 10.2 and standard diviation 2.25 use 5% level of 
#	significance.
n=400
mean=10.2
sd=2.25
mo=10
z=(mean-mo)/(sd/sqrt(n))
z

pval=2*(1-pnorm(abs(z)))
pval
#CONCLUSION-Since pvalue(z) is greater than LOS (pval) therefore reject the H0 at 
#	5% level significance.	 


#Q2	A sample of 900 members has a mean height=3.4 cm & SD is 2.61 cm is sample
#	from range population of mean 3.25 & SD is 2.61.
#	Find 95% level of significance
mean=3.4
n=900
sd=2.61
mo=3.25
z=(mean-mo)/(sd/sqrt(n))
z

pval=2*(1-pnorm(abs(z)))
pval
#CONCLUSION-Since pvalue(z) is greater than LOS (pval) therefore reject the H0 at 
#	5% level significance


#TEST OF SIGNIFICANCE OF DIFFERENCE OF MEAN
#Q1	Two random sample of size 1000 and 2000 are drawn from 2 population with
#	same SD 5 given mean 67.5 $ 68 respectively. Test the hypothesis at 5% 
#	level of significance.
n1=1000
n2=2000
sd=2.5
x1=67.5
x2=68
z=(x1-x2)/(sqrt(((sd*sd)/n1)+(sd*sd)/n2))
z

pval=2*(1-pnorm(abz(z)))
pval
#CONCLUSION-Since pvalue(z) is Smaller than LOS (pval) therefore accept the H0
#	at 5% level significance.


#Q2	The average hourly usage of sample of 150 workers in a plant A was
#	rs.2.56 with SD of rs.1.08 the average hourly usage of sample of 200
#	workers of plant B was rs.2.87 with SD of rs.1.28 can applicant safely
#	assume that hourly wagesa paid by plant B is higher than paid by plant
#	A? Test at 5% level of significance.
n1=100
n2=200
x1=2.56
x2=2.87
sd1=1.08 
sd2=1.28
z=(x1-x2)/(sqrt((sd1*sd2)/n1)+((sd1*sd2)/n2))
z

pval=2*(1-pnorm(abs(z)))
pval
#CONCLUSION-Since pvalue(z) is Smaller than LOS(pval) therefore accept the H0
#	at 95% level significance.

#TEST OF SIGNIFICANCE FOR DIFFERENCE OF PROPORTION
#Q1	from each of two consignment of the apple a sample of size of 200 is 
#	drawn, the no. of red apple counted test 5% level of significance whether
#	the proportion of red apples in 2 consignant are significantly diffrent?

n1=200
n2=200
a=44/200
b=30/200
p1=a
p2=b

p=((n1*p1)+(n2*p2))/(n1+n2)
q=1-p
p
q

z=(p1-p2)/(sqrt((p*q)*((1/n1)+(1/n2))))
z

pval=2*(1-pnorm(abs(z)))
pval
#CONCLUSION-Since pvalue(z) is greater than LOS (pval) therefore reject the H0 at 
#	5% level significance.

#STUDENT T DISTRIBUTION
#Q1	The mean weekely sales of soap in departmental stores were 146.3 per
#	store. After adjusting the campaign the mean weekly sale in 22 stores
#	for typical week increase to 153.7 & show a SD of 17.2.
#	Was the advertising successful?
x=153.7
y=146.3
sd=17.2
n=22
t=(x-y)/(sqrt((sd*sd)/(n-1)))
t

pval=2*(1-pnorm(abs(t)))
pval

#Q2	A mechanic is making engine parts of axel diameter of 0.700 inch a random
#	sample of 10 parts shows a mean diameter of 0.742 inch with SD of 0.040
#	Test wheather work is meeting the specification or not?
x=0.742
y=0.700
n=10
sd=0.040
t=(x-y)/(sqrt((sd*sd)/(n-1)))
t

pval=2*(1-pnorm(abs(t)))
pval

#F DISTRIBUTION
#Q1	If one sample of observations sum of square of diviation of sample from
#	sample mean was 84.4 & in other sample of 10 observations it was 102.6
#	Test whether this difference is significant at 5% LOS given that 5% point
#	of F for n1=7 & n2=9 Degree of freedom is 3.29
n1=7
n2=9
x=64.4
y=102.6
sx=(1/(n1-1)*x)
sx

sy=(1/(n2-1)*y)
sy

f=sx/sy
f

pval=2*(1-pnorm(abs(f)))
pval

#CONCLUSION-Since pvalue(z) is Smaller than LOS(pval) therefore accept the H0
#	at 5% level significance.
