#...Binomial Distribution...

#	dbinom(k,n,p)	where n is total number of trials, 
#	pbinom(k,n,p)		p is probability of success, 
#	qbinom(k,n,p)		k is the value at which the probability has to be found out.
#	rbinom(k,n,p)		k can be a sequence so x in this example or directly 1:50 

x=seq(0,50,by=1)
x
y=dbinom(x,50,0.6)		
y
png(file="I:\\Cl\\Pra S4\\COST\\dbinom.png")	#Give chart file a name
plot(x,y)							#Plot the chart
dev.off()							#Save the file

#...pbinorm...
x=pbinom(26,50,0.5)	
x

#...qbinom...
x=qbinom(0.25,51,0ca.5)	
x

#...rbinom...
x=rbinom(8,150,0.4)					
#GIVES RANDOM DISTRIBUTION
x

#...Normal Distribution...

#	dnorm(x,mean,sd)	Where	x is a vector in no.
#	pnorm(x,mean,sd)		p is a vector of probabilities
#	qnorm(p,mean,sd)		n is no. of observations
#	rnorm(n,mean,sd)		mean is mean value of sample data
#					sd is standard diviation. Dedault SD is 1(one)

#...dnorm...
x=seq(-10,10,by=.1)
x
mean(x)
y=dnorm(x,2.5,0.5)
y
png(file="I:\\Cl\\Pra S4\\COST\\dnorm.png")
plot(x,y)
dev.off()

#...pnorm...
x=seq(-10,10,by=.2)
x
y=pnorm(x,2.5,2)
y
png(file="I:\\Cl\\Pra S4\\COST\\pnorm.png")
plot(x,y)
dev.off()

#...qnorm...
x=seq(0,1,by=0.02)
x
y=qnorm(x,2,1)
y
png(file="I:\\Cl\\Pra S4\\COST\\qnorm.png")
plot(x,y)
dev.off()

#..rnorm...
y=rnorm(50)
png(file="I:\\Cl\\Pra S4\\COST\\rnorm.png")
hist(y,main="Normal Distribution")
dev.off()
