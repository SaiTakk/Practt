library(xlsx)					#Load xlsx library... NOT RRQUIRED FOR .csv FILE
Data=read.csv(file.choose(),header=T)	#Load csv file from excel, file.choose will let you choose a file.
Data
attach(Data)
attach(Data)
var(Mar)				#Variance for Mar col
sd(Hindi)				#SD=Standard Deviation?? Maybe