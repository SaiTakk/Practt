#INSTALL exceldata AND xlsx PACKAGE FROM PACKAGE TAB FIRST
library(xlsx)		#Load xlsx library... NOT RRQUIRED FOR .csv FILE
Data=read.csv(file.choose(),header=T)
Data
attach(Data)		#More info:https://www.google.com/search?q=r+programming+attach+command&client=firefox-b-d&sca_esv=c18275b0ed1961c7&ei=Sob2ZY2vFv64vr0Pkqqe2Ak&oq=r+programming+atta&gs_lp=Egxnd3Mtd2l6LXNlcnAiEnIgcHJvZ3JhbW1pbmcgYXR0YSoCCAAyCBAAGBYYHhgPMggQABgWGB4YDzIGEAAYFhgeMgsQABiABBiKBRiGAzILEAAYgAQYigUYhgMyCxAAGIAEGIoFGIYDMgsQABiABBiKBRiGA0iUFVCVAVjrCnABeACQAQCYAbQBoAHkBaoBAzAuNbgBAcgBAPgBAZgCBaAC0QTCAgoQABhHGNYEGLADwgILEAAYgAQYigUYkQLCAgUQABiABJgDAIgGAZAGCJIHAzEuNKAHzh0&sclient=gws-wiz-serp
attach(Data)		#Explanation from above line: The most common way in introductory books on R is to use "attach(myData)." This essentially makes a copy of every variable in myData and puts those copies in a place (called an environment") where you can address them by name.
mean(Mar)			#mean for Mar col
median(Mar)			#median for Mar col
quantile(Mar)		#quantile for Mar col
hist(Mar)			#histrogram graph for Mar col
IQR(Hindi)			#interquartile for Hindi col		
range=max(Mar)-min(Mar)	#range usin min and max for Mar col
range				#print range
summary(Hindi)		#summary for Hindi col