#Matrix 1
a=matrix(1:9,nrow=3,ncol=3,byrow=TRUE)
print("Matrix 1 is:")
a

#Matrix 2
b=matrix(2:10,nrow=3,ncol=3,byrow=TRUE)
print("Matrix 2 is:")
b

#Addition
add=a+b
print("Addition is:")
add

#Subtraction
sub=a-b
print("Substration is:")
sub

#Multiplication
mul=a*b
print("Multiplication is:")
mul

#Naming elements
row=c("A","B")
col=c("a","b")
p=matrix(1:4,nrow=2,ncol=2,byrow=TRUE,dimnames=list(row,col))
p

#Access elements
a=matrix(1:9,nrow=3,ncol=3,byrow=TRUE)
a
a[3,2]				#element in 3rd row and 2nd col
a[3,]					#elements in 3rd row

#Transpose
a=matrix(1:9,nrow=3,ncol=3,byrow=TRUE)
a
t(a);					#row become col and vice versa

#Determinant and Inverse
mat=matrix(c(1,2,-2,-1,3,0,0,-2,1),nrow=3,ncol=3,byrow=TRUE)
mat

det(mat)				#determinant

#COUDN"T FIND INVERSE FUNC




